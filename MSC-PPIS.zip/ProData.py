import torch
import pickle
import numpy as np
import torch.nn as nn
from torch.utils.data import Dataset
from torch_geometric.data import Data, Batch
import scipy.sparse as sp
from scipy.spatial.distance import cdist

from typing import Any, Optional

import torch.nn.functional as F

from torch_geometric.utils.num_nodes import maybe_num_nodes
from torch_scatter import scatter_add
from torch_geometric.utils import (get_laplacian, to_scipy_sparse_matrix, to_dense_adj)

Feature_Path = "./Feature/"

MAP_CUTOFF = 14
ATOM_MAP_CUTOFF = 4
DIST_NORM = 15

def eigvec_normalizer(EigVecs, EigVals, normalization="L2", eps=1e-12):
    """
    Implement different eigenvector normalizations.
    """

    EigVals = EigVals.unsqueeze(0)

    if normalization == "L1":
        # L1 normalization: eigvec / sum(abs(eigvec))
        denom = EigVecs.norm(p=1, dim=0, keepdim=True)

    elif normalization == "L2":
        # L2 normalization: eigvec / sqrt(sum(eigvec^2))
        denom = EigVecs.norm(p=2, dim=0, keepdim=True)

    elif normalization == "abs-max":
        # AbsMax normalization: eigvec / max|eigvec|
        denom = torch.max(EigVecs.abs(), dim=0, keepdim=True).values

    elif normalization == "wavelength":
        # AbsMax normalization, followed by wavelength multiplication:
        # eigvec * pi / (2 * max|eigvec| * sqrt(eigval))
        denom = torch.max(EigVecs.abs(), dim=0, keepdim=True).values
        eigval_denom = torch.sqrt(EigVals)
        eigval_denom[EigVals < eps] = 1  # Problem with eigval = 0
        denom = denom * eigval_denom * 2 / np.pi

    elif normalization == "wavelength-asin":
        # AbsMax normalization, followed by arcsin and wavelength multiplication:
        # arcsin(eigvec / max|eigvec|)  /  sqrt(eigval)
        denom_temp = torch.max(EigVecs.abs(), dim=0, keepdim=True).values.clamp_min(eps).expand_as(EigVecs)
        EigVecs = torch.asin(EigVecs / denom_temp)
        eigval_denom = torch.sqrt(EigVals)
        eigval_denom[EigVals < eps] = 1  # Problem with eigval = 0
        denom = eigval_denom

    elif normalization == "wavelength-soft":
        # AbsSoftmax normalization, followed by wavelength multiplication:
        # eigvec / (softmax|eigvec| * sqrt(eigval))
        denom = (F.softmax(EigVecs.abs(), dim=0) * EigVecs.abs()).sum(dim=0, keepdim=True)
        eigval_denom = torch.sqrt(EigVals)
        eigval_denom[EigVals < eps] = 1  # Problem with eigval = 0
        denom = denom * eigval_denom

    else:
        raise ValueError(f"Unsupported normalization `{normalization}`")

    denom = denom.clamp_min(eps).expand_as(EigVecs)
    EigVecs = EigVecs / denom

    return EigVecs

def get_lap_decomp_stats(evals, evects, max_freqs, eigvec_norm='L2'):
    """Compute Laplacian eigen-decomposition-based PE stats of the given graph.

    Args:
        evals, evects: Precomputed eigen-decomposition
        max_freqs: Maximum number of top smallest frequencies / eigenvecs to use
        eigvec_norm: Normalization for the eigen vectors of the Laplacian
    Returns:
        Tensor (num_nodes, max_freqs, 1) eigenvalues repeated for each node
        Tensor (num_nodes, max_freqs) of eigenvector values per node
    """
    N = len(evals)  # Number of nodes, including disconnected nodes.

    # Keep up to the maximum desired number of frequencies.
    idx = evals.argsort()[:max_freqs]
    evals, evects = evals[idx], np.real(evects[:, idx])
    evals = torch.from_numpy(np.real(evals)).clamp_min(0)

    # Normalize and pad eigen vectors.
    evects = torch.from_numpy(evects).float()
    evects = eigvec_normalizer(evects, evals, normalization=eigvec_norm)
    if N < max_freqs:
        EigVecs = F.pad(evects, (0, max_freqs - N), value=float('nan'))
    else:
        EigVecs = evects

    # Pad and save eigenvalues.
    if N < max_freqs:
        EigVals = F.pad(evals, (0, max_freqs - N), value=float('nan')).unsqueeze(0)
    else:
        EigVals = evals.unsqueeze(0)
    EigVals = EigVals.repeat(N, 1).unsqueeze(2)

    return EigVals, EigVecs

def add_node_attr(
    data: Data,
    value: Any,
    attr_name: Optional[str] = None,
) -> Data:
    # TODO Move to `BaseTransform`.
    if attr_name is None:
        if data.x is not None:
            x = data.x.view(-1, 1) if data.x.dim() == 1 else data.x
            data.x = torch.cat([x, value.to(x.device, x.dtype)], dim=-1)
        else:
            data.x = value
    else:
        data[attr_name] = value

    return data


def get_rw_landing_probs_matrix(ksteps, edge_index, edge_weight=None,
                                num_nodes=None, alpha=0.95):
    """
    计算 k 步随机游走矩阵 P^k，用于作为注意力偏置。

    使用稀疏矩阵迭代计算，避免显存爆炸。

    Args:
        ksteps: List[int], 例如 [1, 2, 4, 8]
        edge_index: PyG edge_index (2, E)
        edge_weight: (E,) 边权重
        num_nodes: 节点数
        alpha: (float) 衰减因子 (0 < alpha <= 1)。
               用于防止 P^k 数值过小导致梯度消失。
               类似于 PageRank 的阻尼系数，通常设为 0.95 或 0.99。

    Returns:
        Tensor: (num_nodes, num_nodes, len(ksteps))
    """
    device = edge_index.device
    if edge_weight is None:
        edge_weight = torch.ones(edge_index.size(1), device=device)

    num_nodes = maybe_num_nodes(edge_index, num_nodes)
    source, dest = edge_index[0], edge_index[1]

    # 1. 构建归一化转移矩阵 P (稀疏格式)
    # P_ij = A_ij / deg(i)
    deg = scatter_add(edge_weight, source, dim=0, dim_size=num_nodes)
    deg_inv = deg.pow(-1.)
    deg_inv.masked_fill_(deg_inv == float('inf'), 0)

    # 归一化边权重
    norm_edge_weight = edge_weight * deg_inv[source]

    # 构建稀疏张量 P
    P_sparse = torch.sparse_coo_tensor(edge_index, norm_edge_weight, (num_nodes, num_nodes))
    P_sparse = P_sparse.coalesce()

    # 2. 准备存储结果的列表
    rw_matrices = []

    # 对 ksteps 排序以便利用迭代性质 (P^k -> P^(k+1))
    sorted_ksteps = sorted(ksteps)
    current_k = 0
    # 初始状态 P^0 = I (单位矩阵)
    Pk = torch.sparse_coo_tensor(
        torch.arange(num_nodes, device=device).unsqueeze(0).repeat(2, 1),
        torch.ones(num_nodes, device=device),
        (num_nodes, num_nodes)
    ).coalesce()

    # 3. 迭代计算
    # 注意：这里我们计算的是稠密结果以便后续作为偏置，
    # 但如果 N 很大，建议只提取对角线或特定位置，不要转 dense。
    # 这里假设你需要完整的 N*N 偏置矩阵。

    # 将 P^0 转为稠密以便后续累加 (如果 N 太大，这里会 OOM，需注意)
    # 如果 N > 5000，建议不要生成完整的 N*N*K 矩阵，而是用 Sparse Attention 机制
    Pk_dense = Pk.to_dense()

    for k in range(1, max(sorted_ksteps) + 1):
        # Pk = Pk @ P (稀疏矩阵乘稠密矩阵)
        # torch.sparse.mm 支持 (Sparse x Dense) -> Dense
        Pk_dense = torch.sparse.mm(P_sparse, Pk_dense)

        # 应用 alpha 衰减，保持数值稳定
        # 这一步相当于计算 alpha * P^k
        Pk_dense = Pk_dense * alpha

        if k in sorted_ksteps:
            rw_matrices.append(Pk_dense)

    # 4. 按照原始 ksteps 顺序重组
    # 建立 k -> index 的映射
    k_to_idx = {k: i for i, k in enumerate(sorted_ksteps)}
    final_matrices = []
    for k in ksteps:
        final_matrices.append(rw_matrices[k_to_idx[k]])

    # 堆叠: (N, N, K)
    result = torch.stack(final_matrices, dim=0).permute(1, 2, 0)

    return result

def compute_posenc_stats(data, pe_types, times, max_freqs=None, eigvec_norm=None):
    """Precompute positional encodings for the given graph.

    Supported PE statistics to precompute, selected by `pe_types`:
    'LapPE': Laplacian eigen-decomposition.
    'RWSE': Random walk landing probabilities (diagonals of RW matrices).
    'HKfullPE': Full heat kernels and their diagonals. (NOT IMPLEMENTED)
    'HKdiagSE': Diagonals of heat kernel diffusion.
    'ElstaticSE': Kernel based on the electrostatic interaction between nodes.

    Args:
        data: PyG graph
        pe_types: Positional encoding types to precompute statistics for.
            This can also be a combination, e.g. 'eigen+rw_landing'
        is_undirected: True if the graph is expected to be undirected
        cfg: Main configuration node

    Returns:
        Extended PyG Data object.
    """
    # Verify PE types.
    for t in pe_types:
        if t not in ['LapPE', 'EquivStableLapPE', 'SignNet', 'RWSE', 'HKdiagSE', 'HKfullPE', 'ElstaticSE', 'addEigvals']:
            raise ValueError(f"Unexpected PE stats selection {t} in {pe_types}")

    # Basic preprocessing of the input graph.
    if hasattr(data, 'num_nodes'):
        N = data.num_nodes  # Explicitly given number of nodes, e.g. ogbg-ppa
    else:
        N = data.x.shape[0]  # Number of nodes, including disconnected nodes.

    # Eigen values and vectors.
    evals, evects = None, None

    # Random Walks.
    if 'RWSE' in pe_types:
        rw_landing = get_rw_landing_probs_matrix(times,
                                          edge_index=data.edge_index,
                                          num_nodes=N)
        data.pestat_RWSE = rw_landing

    if 'LapPE' in pe_types:
        assert data.edge_index is not None
        num_nodes = data.num_nodes
        assert num_nodes is not None

        edge_index, edge_weight = get_laplacian(
            data.edge_index,
            data.edge_weight,
            normalization='sym',
            num_nodes=num_nodes,
        )
        # L = to_dense_adj(edge_index, edge_attr=edge_weight, max_num_nodes=num_nodes).squeeze(dim=0)
        # Lambda = torch.zeros(1, 10)
        # V = torch.zeros(num_nodes, 10)
        # d = min(num_nodes, 10)
        # eigenvalues, eigenvectors = torch.linalg.eigh(L)
        # Lambda[0, :d] = eigenvalues[0:d]
        # V[:, :d] = eigenvectors[:, 0:d]


        L = to_scipy_sparse_matrix(edge_index, edge_weight, num_nodes)

        is_undirected = True

        if num_nodes < 100:
            from numpy.linalg import eig, eigh
            eig_fn = eig if not is_undirected else eigh

            eig_vals, eig_vecs = eig_fn(L.todense())  # type: ignore
        else:
            from scipy.sparse.linalg import eigs, eigsh
            eig_fn = eigs if not is_undirected else eigsh

            eig_vals, eig_vecs = eig_fn(  # type: ignore
                L,
                k= 10 + 1,
                which='SR' if not is_undirected else 'SA',
                return_eigenvectors=True,

            )


        eig_vecs = np.real(eig_vecs[:, eig_vals.argsort()])
        pe = torch.from_numpy(eig_vecs[:, 1:10 + 1])

        sign = -1 + 2 * torch.randint(0, 2, (10,))

        pe *= sign

        # evals_sn, evects_sn = np.linalg.eigh(L.toarray())
        # evals_sn, evects_sn = get_lap_decomp_stats(
        #     evals=evals_sn, evects=evects_sn,
        #     max_freqs=10,
        #     eigvec_norm='L2')


        data = add_node_attr(data, pe, attr_name='pe')
        # data = add_node_attr(data, Lambda, attr_name='Lambda')
        # data = add_node_attr(data, evects_sn, attr_name='eigvecs_sn')

    if 'addEigvals' in pe_types:
        assert data.edge_index is not None
        num_nodes = data.num_nodes
        assert num_nodes is not None

        edge_index, edge_weight = get_laplacian(
            data.edge_index,
            data.edge_weight,
            normalization='sym',
            num_nodes=num_nodes,
        )
        L = to_scipy_sparse_matrix(edge_index, edge_weight, num_nodes)
        evals, evects = np.linalg.eigh(L.toarray())
        EigVals, EigVecs = get_lap_decomp_stats(
            evals=evals, evects=evects,
            max_freqs=10,
            eigvec_norm='L2')
        sign = -1 + 2 * torch.randint(0, 2, (10,))
        EigVecs = EigVecs * sign
        data = add_node_attr(data, EigVals, attr_name='EigVals')
        data = add_node_attr(data, EigVecs, attr_name='EigVecs')

    return data

def add_zeros(data):
    z = data.edge_index.new_zeros(data.edge_index.shape[1])
    data.edge_attr = z
    return data

def get_dssp_features(sequence_name):
    dssp_feature = np.load(Feature_Path + "dssp/" + sequence_name + '.npy')
    return dssp_feature.astype(np.float32)
def embedding(sequence_name):
    pssm_feature = np.load(Feature_Path + "pssm/" + sequence_name + '.npy')
    hmm_feature = np.load(Feature_Path + "hmm/" + sequence_name + '.npy')
    seq_embedding = np.concatenate([pssm_feature, hmm_feature], axis=1)
    return seq_embedding.astype(np.float32)

def get_res_atom_features(sequence_name):
    res_atom_feature = np.load(Feature_Path + "resAF/" + sequence_name + '.npy')
    return res_atom_feature.astype(np.float32)

def cal_edges(sequence_name, radius=MAP_CUTOFF):  # to get the index of the edges
    dist_matrix = np.load(Feature_Path + "distance_map_SC/" + sequence_name + ".npy")
    mask = ((dist_matrix >= 0) * (dist_matrix <= radius))
    adjacency_matrix = mask.astype(int)
    radius_index_list = np.where(adjacency_matrix == 1)
    radius_index_list = [list(nodes) for nodes in radius_index_list]
    return radius_index_list, dist_matrix

def get_ag_node_features(sequence_name):
    ag_node_features = np.load(Feature_Path + "atom_ohe/" + sequence_name + '.npy')
    # zero_column = np.zeros((ag_node_features.shape[0], 1))
    # ag_node_features = np.concatenate((ag_node_features, zero_column), axis=1)
    return ag_node_features.astype(np.float32)

def get_ag_atom_resi_features(sequence_name):
    ag_atom_resi_features = np.load(Feature_Path + "atom_resi_ohe/" + sequence_name + '.npy')
    return ag_atom_resi_features.astype(np.float32)

def get_ar_idx(sequence_name):
    ar_idx = np.load(Feature_Path + "atom_resi_idx/" + sequence_name + '.npy')
    return ar_idx.astype(np.longlong)

def cal_atom_edges(sequence_name, num_nodes, radius=ATOM_MAP_CUTOFF):
    atom_cor = np.load(Feature_Path + "distance_map_atom/" + sequence_name + '.npy')
    distance_matrix = cdist(atom_cor, atom_cor, metric='euclidean')
    mask = ((distance_matrix >= 0) * (distance_matrix <= radius))
    adjacency_matrix = mask.astype(int)
    # vanode = np.load(Feature_Path + "vanode/" + sequence_name + '.npy')
    # adjacency_matrix = np.vstack((adjacency_matrix, vanode))
    # identity_matrix = np.eye(num_nodes)
    # transposed_matrix = vanode.T
    # mid_mtx = np.vstack((transposed_matrix, identity_matrix))
    # adjacency_matrix = np.concatenate((adjacency_matrix, mid_mtx), axis=1)
    radius_index_list = np.where(adjacency_matrix == 1)
    radius_index_list = [list(nodes) for nodes in radius_index_list]
    return radius_index_list

def normalize(mx):
    rowsum = np.array(mx.sum(1))
    r_inv = (rowsum ** -0.5).flatten()
    r_inv[np.isinf(r_inv)] = 0
    r_mat_inv = np.diag(r_inv)
    result = r_mat_inv @ mx @ r_mat_inv
    return result

def load_graph(sequence_name):
    dismap = np.load(Feature_Path + "distance_map_SC/" + sequence_name + ".npy")
    mask = ((dismap >= 0) * (dismap <= MAP_CUTOFF))
    adjacency_matrix = mask.astype(int)
    norm_matrix = normalize(adjacency_matrix.astype(np.float32))
    return norm_matrix

def graph_collate(samples):
    sequence_name, sequence, label, node_features, G, adj_matrix = map(list, zip(*samples))
    label = torch.Tensor(label)
    G_batch = Batch.from_data_list(G)
    node_features = torch.cat(node_features)
    adj_matrix = torch.Tensor(adj_matrix)
    return sequence_name, sequence, label, node_features, G_batch, adj_matrix



def laplace_decomp(g, max_freqs):
    num_nodes = g.num_nodes


    edge_index, edge_weight = get_laplacian(
        g.edge_index,
        g.edge_weight,
        normalization='sym',
        num_nodes=num_nodes,
    )

    L = to_scipy_sparse_matrix(edge_index, edge_weight, num_nodes)

    is_undirected = True

    if num_nodes < 100:
        from numpy.linalg import eig, eigh
        eig_fn = eig if not is_undirected else eigh

        EigVals, EigVecs = eig_fn(L.todense())  # type: ignore
    else:
        from scipy.sparse.linalg import eigs, eigsh
        eig_fn = eigs if not is_undirected else eigsh

        EigVals, EigVecs = eig_fn(  # type: ignore
            L,
            k=10 + 1,
            which='SR' if not is_undirected else 'SA',
            return_eigenvectors=True,

        )

    # EigVals = np.sort(np.abs(np.real(EigVals)))
    EigVals = np.sort(np.abs(np.real(EigVals)))
    if num_nodes < max_freqs:
        EigVals = np.pad(EigVals, (0, max_freqs - num_nodes), 'constant', constant_values=(1))
        EigVecs = np.pad(EigVecs, (0, max_freqs - num_nodes), 'constant', constant_values=(1))
    EigVals, EigVecs = EigVals[: max_freqs], EigVecs[:, :max_freqs]
    if EigVecs.shape[1] < 32:
        EigVecs = np.resize(EigVecs, (EigVecs.shape[0], 32))
    return EigVals, EigVecs

class ProDataset(Dataset):
    def __init__(self, dataframe, radius=MAP_CUTOFF, dist=DIST_NORM, psepos_path='./Feature/psepos/Train335_psepos_SC.pkl'):
        self.names = dataframe['ID'].values
        self.sequences = dataframe['sequence'].values
        self.labels = dataframe['label'].values
        self.residue_psepos = pickle.load(open(psepos_path, 'rb'))
        self.radius = radius
        self.dist = dist
        self.sph = []
        self.dist_list = []
        self.SPD_list = []
        # self.graph = {}
        # self.label = None


    def __getitem__(self, index):
        sequence_name = self.names[index]
        sequence = self.sequences[index]
        #print(sequence)
        label = np.array(self.labels[index])
        nodes_num = len(label)
        pos = self.residue_psepos[sequence_name]



        reference_res_psepos = pos[0]
        pos = pos - reference_res_psepos

        pos = torch.from_numpy(pos)
        pos_cos = pos
        node_dis = torch.cdist(pos, pos)
        # print(node_dis)

        row_max, _ = torch.max(node_dis, dim=1)
        node_dis = row_max - node_dis
        node_dis = node_dis / self.radius

        norms = torch.norm(pos_cos, dim=1)
        dot_product = torch.matmul(pos_cos, pos_cos.T)
        cosine_matrix = ((dot_product / (norms * norms.unsqueeze(1))) + 1) / 2
        cosine_matrix = torch.nan_to_num(cosine_matrix, nan=0.5)

        sequence_embedding = embedding(sequence_name)
        structural_features = get_dssp_features(sequence_name)
        node_features = np.concatenate([sequence_embedding, structural_features], axis=1)
        node_features = torch.from_numpy(node_features)
        #if ADD_NODEFEATS == 'all' or ADD_NODEFEATS == 'atom_feats':
        res_atom_features = get_res_atom_features(sequence_name)
        res_atom_features = torch.from_numpy(res_atom_features)
        node_features = torch.cat([node_features, res_atom_features], dim=-1)
        #if ADD_NODEFEATS == 'all' or ADD_NODEFEATS == 'psepose_embedding':
        node_features = torch.cat([node_features, torch.sqrt(torch.sum(pos * pos, dim=1)).unsqueeze(-1) / self.dist], dim=-1)


        radius_index_list, dismap = cal_edges(sequence_name, MAP_CUTOFF)
        dismap = torch.tensor(dismap, dtype=torch.float)
        # masks = np.ones(node_features.shape[0])
        # masks = torch.tensor(masks, dtype=torch.long)

        edge_feat = self.cal_edge_attr(radius_index_list, pos)
        edge_index_tensor = torch.tensor(radius_index_list)
        edge_feat = np.transpose(edge_feat, (1, 2, 0))
        edge_feat = edge_feat.squeeze(1)
        edge_feat = torch.tensor(edge_feat)
        label_tensor = torch.tensor(label)



        pos = pos.float()

        n = nodes_num
        s = torch.arange(n)
        complete_edge_index = torch.vstack((s.repeat_interleave(n), s.repeat(n)))


        # G = Data(x=node_features, edge_index=edge_index_tensor, y=label_tensor, edge_attr=edge_feat, pos=pos,
        #          spd_list=spd_list, dist_list=dist_list, complete_edge_index=complete_edge_index, SE=SE)
        G = Data(x=node_features, edge_index=edge_index_tensor, y=label_tensor, pos=pos,
                  edge_attr=edge_feat)
        G = add_zeros(G)
        G = compute_posenc_stats(G, pe_types=['LapPE'], times=list(range(1, 7 + 1)))

        G = compute_posenc_stats(G, pe_types=['RWSE'], times=list(range(1, 7 + 1)))


        adj_matrix = load_graph(sequence_name)
        node_features = node_features.detach().numpy()
        node_features = node_features[np.newaxis, :, :]
        node_features = torch.from_numpy(node_features).type(torch.FloatTensor)

        return G

        # return sequence_name, sequence, label, node_features, G, adj_matrix

    def __len__(self):
        return len(self.labels)

    def cal_edge_attr(self, index_list, pos):
        pdist = nn.PairwiseDistance(p=2, keepdim=True)
        cossim = nn.CosineSimilarity(dim=1)
        distance = (pdist(pos[index_list[0]], pos[index_list[1]]) / self.radius).detach().numpy()

        cos = ((cossim(pos[index_list[0]], pos[index_list[1]]).unsqueeze(-1) + 1) / 2).detach().numpy()


        radius_attr_list = np.array([distance, cos])
        return radius_attr_list

    def add_edges_custom(self, G, radius_index_list, edge_features):
        src, dst = radius_index_list[1], radius_index_list[0]
        if len(src) != len(dst):
            print('source and destination array should have been of the same length: src and dst:', len(src), len(dst))
            raise Exception
        G.add_edges(src, dst)
        G.edata['ex'] = torch.tensor(edge_features)

    def process(self, index):
        label = np.array(self.labels[index])
        N = len(label)
        adj = torch.zeros([N, N])
        sequence_name = self.names[index]
        radius_index_list = cal_edges(sequence_name, MAP_CUTOFF)
        edge_index_tensor = torch.tensor(radius_index_list)
        adj[edge_index_tensor[0, :], edge_index_tensor[1, :]] = True

        sp, _ = torch.tensor(algos.floyd_warshall(adj.numpy()))


        self.sph.append(sp)





