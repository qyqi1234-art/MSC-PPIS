from torch_scatter import scatter_add
import torch

def dirichlet_energy_gcn(x, edge_index):
    N = x.size(0)
    deg = scatter_add(torch.ones(edge_index.size(1), device=x.device),
                      edge_index[0], dim=0, dim_size=N)
    norm = (deg + 1).sqrt().clamp(min=1e-12)
    x_norm = x / norm.unsqueeze(-1)
    src, dst = edge_index
    diff = x_norm[src] - x_norm[dst]
    rzt = (diff * diff).sum()
    frob_norm_sq = (x ** 2).sum()
    return rzt / (frob_norm_sq + 1e-8)