

import math 
from typing import Optional, Tuple 

import torch 
from torch import Tensor 

from torch import nn 
from torch_geometric.utils import to_dense_batch
from torch_geometric.utils import degree


@torch.no_grad()
def get_log_deg(edge_index, num_nodes):
    # if "log_deg" in batch:
    #     log_deg = batch.log_deg
    # elif "deg" in batch:
    #     deg = batch.deg
    #     log_deg = torch.log(deg + 1).unsqueeze(-1)
    # else:
        #warnings.warn("Compute the degree on the fly; Might be problematric if have applied edge-padding to complete graphs")
    deg = degree(edge_index[1], num_nodes=num_nodes, dtype=torch.float)
    log_deg = torch.log(deg + 1)
    log_deg = log_deg.view(num_nodes, 1)
    return log_deg

def mask_attention_score(attention_score: torch.Tensor, attention_mask: torch.Tensor, mask_pos_value: float = 0.0):
    """Mask the attention score with the attention_mask || b: batch_size, l: seq_len, d: hidden_dims, h: num_heads

    Args:
        attention_score (torch.Tensor): The attention score with shape (b, h, l, l) or (b, l, l).
        attention_mask (torch.Tensor): The attention mask with shape (b, l) or (b, l, l).
        mask_pos_value (float, optional): The value of the position to be masked. Defaults to 0.0.
    Returns:
        torch.Tensor: The masked attention score with shape (b, h, l, l) or (b, l, l).
    """
    shape = attention_score.shape
    b, h, l, _ = shape if len(shape) == 4 else (shape[0], 1, shape[1], shape[2])
    # (b, l, l) -> (b, 1, l, l) if (b, l, l) else (b, h, l, l)
    attention_score = attention_score.view(b, h, l, l) if len(shape) == 3 else attention_score
    # (b, l) -> (b*h, l)
    attention_mask = attention_mask.repeat_interleave(h, dim=0)  # (b*h, l) or (b*h, l, l)
    attention_mask = attention_mask.view(b, h, -1, l)  # (b, h, 1, l) or (b, h, l, l)
    # attention_mask = (1 - attention_mask) * (-100000.0)
    # attention_score += attention_mask  # (b, h, l, l)
    attention_score = attention_score.masked_fill(attention_mask == mask_pos_value, -10000.0)
    return attention_score.view(shape) if len(shape) == 3 else attention_score

class MultiHeadAttention(nn.Module):

    def __init__(self, hidden_dim: int, num_heads: int,
            dropout_ratio: float = 0.1):

        super().__init__()
        self.num_heads = num_heads
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.dropout = nn.Dropout(dropout_ratio)

        self.linear_q = nn.Linear(hidden_dim, hidden_dim)
        self.linear_k = nn.Linear(hidden_dim, hidden_dim)
        self.linear_v = nn.Linear(hidden_dim, hidden_dim)

        self.linear_attn_out = nn.Linear(hidden_dim, hidden_dim)

        self.weight_A = torch.randn(num_heads).view(1, num_heads, 1, 1)
        self.weight_A = nn.Parameter(self.weight_A, requires_grad=True)
        self.weight_D = torch.randn(num_heads).view(1, num_heads, 1, 1)
        self.weight_D = nn.Parameter(self.weight_D, requires_grad=True)

        self.rw_gate = torch.nn.Parameter(torch.tensor(0.0))
        self.rw_linear = nn.Linear(7, 4)

    def reset_parameters(self):
        self.linear_q.reset_parameters()
        self.linear_k.reset_parameters()
        self.linear_v.reset_parameters()
        self.linear_attn_out.reset_parameters()

    def forward(
        self,
        x_q: Tensor,
        x_k: Tensor,
        x_v: Tensor,
        mask: Tensor,
        rw_bias: Tensor,
    ) -> Tensor:   # B x N x F -> B x N x F

        Q = self.linear_q(x_q)
        K = self.linear_k(x_k)
        V = self.linear_v(x_v)


        dim_split = self.hidden_dim // self.num_heads
        Q_heads = torch.cat(Q.split(dim_split, 2), dim=0)
        K_heads = torch.cat(K.split(dim_split, 2), dim=0)
        V_heads = torch.cat(V.split(dim_split, 2), dim=0)



        attention_score = Q_heads.bmm(K_heads.transpose(1, 2))



        attention_score = attention_score / math.sqrt(self.hidden_dim // self.num_heads)
        rw_bias = self.rw_linear(rw_bias)
        rw_bias = rw_bias.permute(0, 3, 1, 2)
        rw_bias = rw_bias.reshape(-1, attention_score.shape[1], attention_score.shape[1])




        rw_bias_final = rw_bias

        inf_mask = (~mask).unsqueeze(1).to(dtype=torch.float) * -1e9
        inf_mask = torch.cat([inf_mask for _ in range(self.num_heads)], 0)

        #不加随机游走偏置
        A = torch.softmax(attention_score + inf_mask, -1)

        # A = torch.softmax(attention_score + inf_mask + rw_bias_final, -1)



        A = self.dropout(A)
        out = torch.cat((A.bmm(V_heads)).split(Q.size(0), 0), 2)

        out = self.linear_attn_out(out)

        return out


class NodeSelfAttention(MultiHeadAttention):

    def __init__(self, hidden_dim: int, num_heads: int,
            dropout_ratio: float = 0.1):
        super().__init__(hidden_dim, num_heads,
                            dropout_ratio)

    def forward(
        self,
        x: Tensor,
        mask: Tensor,
        rw_bias: Tensor,
    ) -> Tensor:

        return super().forward(x, x, x, mask, rw_bias)
        

class GraphTransformerEncoderLayer(nn.Module): 
    
    def __init__(self, hidden_dim, num_heads: int, 
            attn_dropout_ratio: float = 0.0,
            dropout_ratio: float = 0.0,
            ffn_hidden_times: int = 2, 
            norm: str = 'ln'): 
        
        super().__init__() 
        self.hidden_dim = hidden_dim 
        self.num_heads = num_heads 

        if norm == 'ln':
            norm_class = nn.LayerNorm 
        elif norm == 'bn': 
            norm_class = nn.BatchNorm1d 

        self.dropout1 = nn.Dropout(dropout_ratio) 
        self.dropout2 = nn.Dropout(dropout_ratio) 
        self.dropout3 = nn.Dropout(dropout_ratio) 
        
        self.node_self_attention = NodeSelfAttention(
                                    hidden_dim, num_heads,
                                    attn_dropout_ratio)




        self.cat_lin = nn.Linear(128, 64)
        self.cat_drop = nn.Dropout(0.2)


        self.linear_out1 = nn.Linear(hidden_dim, ffn_hidden_times * hidden_dim)
        self.linear_out2 = nn.Linear(ffn_hidden_times * hidden_dim, hidden_dim) 

        self.norm0 = norm_class(hidden_dim) 
        self.norm1 = norm_class(hidden_dim)
        self.structure_map_query = nn.Sequential(nn.Linear(32, num_heads))
        self.conv1d = nn.Conv1d(64, 64, 3, 1, 1)

        self.deg_coef = nn.Parameter(torch.zeros(1, 64, 2))
        nn.init.xavier_normal_(self.deg_coef)
        self.pre_bn = nn.BatchNorm1d(64)

        self.gate_main = nn.Sequential(nn.Linear(64, 64), nn.Sigmoid())
        self.gate_sub = nn.Sequential(nn.Linear(64, 64), nn.Sigmoid())
        self.gate_trans = nn.Sequential(nn.Linear(64, 64), nn.Sigmoid())

        self.fuse_norm = nn.BatchNorm1d(64)

    def reset_parameters(self): 
        # self.node_self_attention.reset_parameters()
        self.linear_out1.reset_parameters() 
        self.linear_out2.reset_parameters() 
        self.norm0.reset_parameters()
        self.norm1.reset_parameters()
        self.attn.reset_parameters()
        self.pre_bn.reset_parameters()
        self.fuse_norm.reset_parameters()
        
    def forward(self, graph: Optional[Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]]):

        # Sparse -> Dense 
        x, batch, batch_CLS, edge_index, gx, rw_cal= graph
        rw_bias = rw_cal
        num_nodes = x.shape[0]

        x_dense, mask = to_dense_batch(x, batch) 
        attention_mask = mask


        if batch_CLS is not None: 
            x_dense = torch.cat([x_dense, batch_CLS], dim=1) 
            CLS_mask = torch.full((batch_CLS.shape[0], 1), True, device=batch_CLS.device) 
            attention_mask = torch.cat([mask, CLS_mask], dim=1) 

        attention_out = self.node_self_attention(x_dense, attention_mask, rw_bias)


        attention_out = self.dropout1(attention_out)
        attention_out = attention_out + x_dense


        if batch_CLS is not None: 
            batch_CLS = attention_out[:, -1, :] 
            attention_out = attention_out[:, :-1, :] 
            attention_out = attention_out[mask] 
            attention_out = torch.cat((attention_out, batch_CLS), dim=0) 
        else:
            attention_out = attention_out[mask]


        attention_out = self.norm0(attention_out)


        attention_out = attention_out + gx


        out = self.linear_out1(attention_out)
        out = torch.relu(out)
        out = self.dropout2(out)
        out = self.linear_out2(out)
        out = self.dropout3(out)

        out = out + attention_out

        out = self.norm1(out)


        return out
