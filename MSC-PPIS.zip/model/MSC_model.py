
import numpy as np
from typing import Union, List, Callable
import os

import math 
import pandas as pd
from torch_geometric.utils import unbatch

import torch 
from torch import Tensor 
from torch import nn 
from torch.nn import init
from torch.nn import LeakyReLU, ReLU, Parameter, BatchNorm1d, Sigmoid

from torch_geometric.nn import global_add_pool, global_mean_pool, global_max_pool, GATConv, GCNConv, GINConv
from torch_geometric.data import Batch, Data 

import scipy.sparse as sp

from .tlayer import GraphTransformerEncoderLayer 
from .rwse import RW_StructuralEncoder 

from .egnn_clean import E_GCL

from torch_geometric.nn import PositionalEncoding

from .mlp import MLP


from .ClusterPooling import ClusterPooling


def randomedge_sampler(train_adj, percent, num):
    """
    Randomly drop edge and preserve percent% edges.
    """
    "Opt here"

    nnz = train_adj.shape[1]
    data = [1] * nnz
    row = train_adj[0].cpu().numpy()
    col = train_adj[1].cpu().numpy()
    shape = (nnz, nnz)
    train_adj = sp.coo_matrix((data, (row, col)), shape=shape)
    # print(train_adj)
    perm = np.random.permutation(nnz)
    preserve_nnz = int(nnz * percent)

    perm = perm[:preserve_nnz]
    r_adj = sp.coo_matrix((train_adj.data[perm],
                           (train_adj.row[perm],
                            train_adj.col[perm])),
                          shape=train_adj.shape)
    adj = torch.zeros([num, num])
    adj[r_adj.row[:], r_adj.col[:]] = True
    adj = adj.numpy()
    np.fill_diagonal(adj, 1)
    radius_index_list = np.where(adj == 1)
    radius_index_list = [list(nodes) for nodes in radius_index_list]
    final_adj = torch.tensor(radius_index_list)


    return final_adj

def process_hop(sph, rw_conv, gamma, hop, slope=0.1):
    leakyReLU = LeakyReLU(negative_slope=slope)
    relu = ReLU()
    sigmoid = Sigmoid()


    sph = sph.unsqueeze(1)
    sph = sph - hop

    sph = leakyReLU(sph)

    sp = torch.pow(gamma, sph)


    return sp


def renumber_segments_tensor(tensor):
    """将分段连续编号的 PyTorch 张量转换为全局连续编号"""
    if tensor.numel() == 0:
        return tensor

    # 1. 找到所有分段变化点的索引（包括开头和结尾）
    changes = torch.where(tensor[:-1] != tensor[1:])[0] + 1
    change_points = torch.cat([
        torch.tensor([0], device=tensor.device),
        changes,
        torch.tensor([len(tensor)], device=tensor.device)
    ])

    # 2. 计算每个分段的全局ID
    output = torch.zeros_like(tensor)
    global_id = 1  # 起始编号

    for i in range(len(change_points) - 1):
        start, end = change_points[i], change_points[i + 1]
        output[start:end] = global_id
        global_id += 1

    return output


class CateFeatureEmbedding(nn.Module):
    def __init__(self, num_uniq_values, embed_dim, dropout=0.0):
        '''
        '''
        super().__init__()
        if len(num_uniq_values) == 1:
            self.linear = nn.Linear(embed_dim, embed_dim)
        else:
            self.linear = nn.Linear(embed_dim * 2, embed_dim)
        num_uniq_values = torch.LongTensor(num_uniq_values)
        csum = torch.cumsum(num_uniq_values, dim=0)
        num_emb = csum[-1]
        num_uniq_values = torch.LongTensor(num_uniq_values).reshape(1, 1, -1)
        self.register_buffer('num_uniq_values', num_uniq_values)

        starts = torch.cat(
            (torch.LongTensor([0]), csum[:-1])).reshape(1, -1)
        self.register_buffer('starts', starts)

        self.embeddings = nn.Embedding(
            num_emb, embed_dim)

        self.dropout_proba = dropout

        self.layer_norm_output = nn.LayerNorm(embed_dim)
        pass

    def forward(self, x):
        x = x.long()
        # x = x + 1
        if torch.any(x < 0):
            raise RuntimeError(str(x))

        if torch.any(torch.ge(x, self.num_uniq_values)):
            print(torch.max(x[:, :, :, 0]))
            print(torch.max(x[:, :, :, 1]))
            raise RuntimeError(str(x))
            pass

        x = x + self.starts

        if self.training:

            pass

        emb = self.embeddings(x)
        emb = torch.reshape(emb, (emb.shape[0], emb.shape[1], emb.shape[2], -1))
        emb = self.linear(emb)
        return emb

    pass

class MSC_PPIS(nn.Module):

    def __init__(
        self, 
        
        gconv_dim: int, 
        tlayer_dim: int, 
        dataset_name: str, 

        dataset_root = None, 
        num_vocab = None, 
        max_seq_len = None, 
        segment_pooling = None, 

        in_dim = None, 
        out_dim = None, 

        node_num_types = None, 
        edge_num_types = None, 
        dim_pe = None, 
        num_rw_steps = None, 
        
        gconv_attn_dropout: float = 0., 
        gconv_ffn_dropout: float = 0., 
        tlayer_attn_dropout: float = 0., 
        tlayer_ffn_dropout: float = 0., 
        tlayer_ffn_hidden_times: int = 1, 
        gconv_type: str = 'gin', 
        num_layers: int = 4, 
        num_heads: int = 4, 
        middle_layer_type: str = 'none', 
        skip_connection: str = 'none', 
        readout: str = 'mean', 
        norm: str = 'ln', 

        out_layer: int = 1, 
        out_hidden_times: int = 1 
    ): 
        super().__init__() 

        self.gconv_dim = gconv_dim 
        self.tlayer_dim = tlayer_dim 
        self.dataset_name = dataset_name 

        self.dataset_root = dataset_root 
        self.max_seq_len = max_seq_len 

        self.in_dim = in_dim 

        self.node_num_types = node_num_types 
        self.edge_num_types = edge_num_types 
        self.dim_pe = dim_pe 

        self.num_layers = num_layers 
        self.skip_connection = skip_connection 
        self.middle_layer_type = middle_layer_type 
        self.readout = readout
        self.hop = Parameter(torch.full((4, 1, 1), float(4)))
        self.pe_norm = BatchNorm1d(10)
        self.spe_norm = BatchNorm1d(10)
        self.pe_lin = nn.Linear(10, 16)
        self.spe_lin = nn.Linear(10, 16)
        self.rw_conv = nn.Conv2d(in_channels=3, out_channels=1, kernel_size=(1, 1), stride=(1, 1), padding=(0, 0), bias=False)

        self.layer_structure_embed_cate = CateFeatureEmbedding([10+1, 30+1], 64, dropout=0.1)

        self.etdropout = nn.Dropout(0.3)
        self.bias_embedding = nn.Sequential(nn.Linear(2, 32))
        self.pe_encode = nn.ModuleList()

        self.pe_dropout = nn.Dropout(0.3)

        self.node_encoder2 = nn.Linear(64, 48)

        self.mid_linear = nn.Linear(128, 64)
        self.pe_trans_dim = nn.Linear(32, 16)
        self.pe_attn = nn.TransformerEncoderLayer(d_model=16, nhead=4, batch_first=True)



        self.sub_node_lin = nn.Linear(62, 64)
        self.sigmoid = nn.Sigmoid()

        self.gate_fuse = nn.Linear(128,64)

        self.fuse_bn1 = nn.LayerNorm(64)
        self.fuse_bn2 = nn.LayerNorm(64)


        self.mid_mlp = nn.Sequential(
            nn.Linear(64,128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.Dropout(0.3)
        )
        self.mid_bn = nn.BatchNorm1d(64)

        self.rw_linear = nn.Linear(7, 4)
        self.rw_norm = nn.BatchNorm2d(7)


        if segment_pooling == 'mean': 
            self.segment_pooling_fn = global_mean_pool 
        elif segment_pooling == 'max': 
            self.segment_pooling_fn = global_max_pool 
        elif segment_pooling == 'sum': 
            self.segment_pooling_fn = global_add_pool 
        else: 
            self.segment_pooling_fn = None 

        if readout == 'mean': 
            self.readout_fn = global_mean_pool 
        elif readout == 'add': 
            self.readout_fn = global_add_pool 
        elif readout == 'cls': 
            self.CLS = nn.Parameter(torch.randn(1, tlayer_dim)) 
        else: 
            pass 

        self.init_node_edge_encoders() 

        self.se_encoder = None 
        if num_rw_steps: 
            self.se_encoder = RW_StructuralEncoder(dim_pe, num_rw_steps,
                                model_type='linear', 
                                n_layers=2, 
                                norm_type='bn') 

        self.graph_pred_linear_list = None 
        self.predict_head = None 
        if dataset_name == 'ogbg-code2': 
            self.graph_pred_linear_list = nn.ModuleList() 
            for i in range(max_seq_len): 
                self.graph_pred_linear_list.append(nn.Linear(tlayer_dim, num_vocab)) 
        else: 
            predict_head_modules = [] 
            last_layer_dim = gconv_dim * 2
            for i in range(out_layer-1): 
                predict_head_modules.append(nn.Linear(last_layer_dim, 64))
                predict_head_modules.append(nn.ReLU())
                predict_head_modules.append(nn.Dropout(0.3))

            predict_head_modules.append(nn.Linear(64, out_dim))
            self.predict_head = nn.Sequential(*predict_head_modules) 

        self.gconvs = nn.ModuleList()
        self.graph_norms = nn.ModuleList()
        self.tlayers = nn.ModuleList()
        self.elayers = nn.ModuleList()
        self.etlayer = nn.ModuleList()
        self.middle_layers = nn.ModuleList()
        self.middle_edge_norm = nn.ModuleList()
        self.spe = PositionalEncoding(10)
        self.gps = nn.ModuleList()


        self.subgraph_egnn = nn.ModuleList()
        self.gate = nn.ModuleList()

        self.sub_pre_mid = nn.ModuleList()
        self.atom_graphs = nn.ModuleList()
        self.atom_middle_layers = nn.ModuleList()
        self.atom_tlayers = nn.ModuleList()
        self.sub_pre_egnn = nn.ModuleList()
        self.sub_mid = nn.ModuleList()

        self.cluster_pooling1 = ClusterPooling(64)
        self.cluster_pooling2 = ClusterPooling(64)




        for i in range(2):

            self.sub_pre_mid.append(BatchNorm1d(64))
            self.atom_graphs.append(E_GCL(gconv_dim, gconv_dim, gconv_dim, 0))
            self.atom_middle_layers.append(nn.BatchNorm1d(gconv_dim))
            self.atom_tlayers.append(
                GraphTransformerEncoderLayer(
                    tlayer_dim,
                    num_heads,
                    attn_dropout_ratio=tlayer_attn_dropout,
                    dropout_ratio=tlayer_ffn_dropout,
                    ffn_hidden_times=tlayer_ffn_hidden_times,
                    norm=norm))



        for i in range(num_layers):

            self.gate.append(nn.Linear(128, 64))
            self.sub_pre_egnn.append(E_GCL(gconv_dim, gconv_dim, gconv_dim, 0))


            self.sub_mid.append(nn.BatchNorm1d(64))

            if gconv_type == 'gin': 
                self.gconvs.append(GINConv(gconv_dim)) 
            elif gconv_type == 'gcn': 
                if self.dataset_name == 'ogbg-code2': 
                    self.gconvs.append(GCNConv(gconv_dim, 128)) 
                else: 
                    self.gconvs.append(GCNConv(gconv_dim, gconv_dim)) 

            elif gconv_type == 'egnn':
                if i == 0:
                    self.gconvs.append(E_GCL(gconv_dim, gconv_dim, gconv_dim, 0))
                else:
                    self.gconvs.append(E_GCL(gconv_dim, gconv_dim, gconv_dim, 0))


            elif gconv_type == 'gat':
                self.gconvs.append(GATConv(in_channels=64, out_channels=16, heads=4, edge_dim=64, dropout=0.2))


            if middle_layer_type == 'residual': 
                self.middle_layers.append(nn.BatchNorm1d(64))


            elif middle_layer_type == 'mlp': 
                self.middle_layers.append(nn.Sequential(
                    nn.Dropout(gconv_ffn_dropout), 
                    nn.Linear(gconv_dim, gconv_dim), 
                    nn.LayerNorm(gconv_dim), 
                    nn.ReLU(), 
                    nn.Dropout(gconv_ffn_dropout) 
                )) 
            
            self.tlayers.append(
                GraphTransformerEncoderLayer(
                    tlayer_dim,
                    num_heads,
                    attn_dropout_ratio=tlayer_attn_dropout,
                    dropout_ratio=tlayer_ffn_dropout,
                    ffn_hidden_times=tlayer_ffn_hidden_times,
                    norm=norm))


            self.middle_edge_norm.append(nn.BatchNorm1d(64))


            self.subgraph_egnn.append(GCNConv(64, 64))

    def init_node_edge_encoders(self): 
        if self.dataset_name == 'ogbg-code2': 
            nodetypes_mapping = pd.read_csv(os.path.join(self.dataset_root, 'mapping', 'typeidx2type.csv.gz')) 
            nodeattributes_mapping = pd.read_csv(os.path.join(self.dataset_root, 'mapping', 'attridx2attr.csv.gz')) 

            self.edge_encoder = nn.Linear(2, 128) 
        elif self.dataset_name == 'ogbg-molpcba': 
            self.node_encoder = AtomEncoder(self.gconv_dim) 
            self.edge_encoder = BondEncoder(self.gconv_dim) 
        elif self.dataset_name == 'ZINC': 
            self.node_encoder = nn.Embedding(self.node_num_types, self.gconv_dim - self.dim_pe) 
            self.edge_encoder = nn.Embedding(self.edge_num_types, self.gconv_dim) 
        elif self.dataset_name == 'PATTERN' or self.dataset_name == 'CLUSTER': 
            # self.node_encoder = nn.Linear(self.in_dim, self.gconv_dim - self.dim_pe)
            self.node_encoder = nn.Linear(self.in_dim, self.gconv_dim)
            # self.node_encoder = nn.Linear(64, self.gconv_dim - self.dim_pe)
            self.edge_encoder = nn.Embedding(1, self.gconv_dim)

    def reset_parameters(self):

        init.xavier_uniform_(self.rw_conv.weight)
        self.sub_lin.reset_parameters()
        if self.readout == 'cls': 
            init.kaiming_uniform_(self.CLS, a=math.sqrt(5)) 

        if self.dataset_name == 'ogbg-molpcba': 
            for emb in self.node_encoder.atom_embedding_list: 
                emb.reset_parameters() 
            for emb in self.edge_encoder.bond_embedding_list: 
                emb.reset_parameters() 
        else: 
            self.node_encoder.reset_parameters() 
            self.edge_encoder.reset_parameters() 
        
        if self.se_encoder: 
            self.se_encoder.reset_parameters() 
        
        if self.graph_pred_linear_list:
            for layer in self.graph_pred_linear_list: 
                layer.reset_parameters() 
        elif self.predict_head: 
            for layer in self.predict_head: 
                if isinstance(layer, nn.Linear): 
                    layer.reset_parameters() 
            
        for layer in self.gconvs: 
            layer.reset_parameters() 
        for layer in self.tlayers: 
            layer.reset_parameters() 
        for layer in self.middle_layers: 
            if isinstance(layer, nn.BatchNorm1d): 
                layer.reset_parameters() 
            else: 
                for l in layer: 
                    if isinstance(l, nn.Linear) or isinstance(l, nn.LayerNorm):
                        l.reset_parameters()

        for layer in self.atom_middle_layers:
            if isinstance(layer, nn.BatchNorm1d):
                layer.reset_parameters()

        for layer in self.subgraph_egnn:
            layer.reset_parameters()

        for layer in self.sub_mid:
            if isinstance(layer, nn.BatchNorm1d):
                layer.reset_parameters()

    def create_mlp(self, in_dims: int, out_dims: int) -> MLP:
        return MLP(
            2, in_dims, 64, out_dims, True,
            'relu', 0.0
         )

    def forward(self, data: Union[Data, Batch]):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        rw_cal = data.pestat_RWSE
        sub_init_x = x

        pos = data.pos

        if self.dataset_name == 'ogbg-code2': 
            """
            segment graph into subgraphs (if node number > 1000)
            CLS from different subgraphs (same graph) will be global pooled 
            """ 
            node_depth = data.node_depth 
            # use node_segment_batch as batch 
            node_segment_batch = data.node_segment_batch # every 1000 nodes come into 1 segment as 1 subgraph
            subgraphs_to_graph_batch = data.subgraphs_to_graph_batch # which subgraph belongs to which graph, used for cls readout
            num_segments = subgraphs_to_graph_batch.shape[0] # how many subgraphs after segmenting 
            num_graphs = num_segments 
            x = self.node_encoder(x, node_depth.view(-1,)) 
        elif self.dataset_name == 'ogbg-molpcba': 
            x = self.node_encoder(x) 
        else:

            x = x.squeeze(-1)


            x = self.node_encoder(x)


        if self.readout == 'cls': 
            batch_CLS = self.CLS.expand(num_graphs, 1, -1) 
        else: 
            batch_CLS = None 

        if self.middle_layer_type == 'residual': 
            out = x 
        else: 
            out = 0


        gx = x


        gx_out = gx

        all_embeddings = []

        for i in range(self.num_layers):
            sx = gx



            gx, pos, _ = self.gconvs[i](gx, edge_index, pos)


            if self.middle_layer_type == 'residual':
                gx = gx_out + gx
                gx = self.middle_layers[i](gx)

            if i == 1:
                sx, sub_edge_index, _, sub_idx = self.cluster_pooling1(gx, edge_index, batch, pos)
                sx = self.subgraph_egnn[0](sx, sub_edge_index)
                sx = self.fuse_bn1(sx)
                gx = gx + sx[sub_idx[1]]

            if i == 3:
                sx, sub_edge_index, _, sub_idx = self.cluster_pooling2(gx, edge_index, batch, pos)
                sx = self.subgraph_egnn[1](sx, sub_edge_index)
                sx = self.fuse_bn2(sx)
                gx = gx + sx[sub_idx[1]]


            if self.dataset_name == 'ogbg-code2':
                graph = (x, node_segment_batch, batch_CLS, gx, rw_cal)
            else:
                graph = (x, batch, batch_CLS, edge_index, gx, rw_cal)

            x = self.tlayers[i](graph)
            gx=x
            out = gx

            gx_out = out

            all_embeddings.append(gx)


        if self.readout == 'cls':
            out = batch_CLS.squeeze(1) 
            if self.segment_pooling_fn: 
                out = self.segment_pooling_fn(out, subgraphs_to_graph_batch) 
        elif self.readout: 
            out = self.readout_fn(out, batch) 

        if self.graph_pred_linear_list: 
            pred_list = [] 
            for i in range(self.max_seq_len): 
                pred_list.append(self.graph_pred_linear_list[i](out)) 
            out = pred_list 
        elif self.predict_head:
            out = self.predict_head(out) 


        return out, all_embeddings



class StableExpressivePE(nn.Module):
    phi: nn.Module
    psi_list: nn.ModuleList

    def __init__(self, phi: nn.Module, psi_list: List[nn.Module]) -> None:
        super().__init__()
        self.phi = phi
        self.psi_list = nn.ModuleList(psi_list)

    def forward(
        self, Lambda: torch.Tensor, V: torch.Tensor, edge_index: torch.Tensor, batch: torch.Tensor
    ) -> torch.Tensor:
        """
        :param Lambda: Eigenvalue vectors. [B, D_pe]
        :param V: Concatenated eigenvector matrices. [N_sum, D_pe]
        :param edge_index: Graph connectivity in COO format. [2, E_sum]
        :param batch: Batch index vector. [N_sum]
        :return: Positional encoding matrix. [N_sum, D_pe]
        """
        Lambda = Lambda.unsqueeze(dim=2)   # [B, D_pe, 1]
#        Lambda = torch.cat([torch.cat([torch.cos(Lambda / 10000**(i/37)), torch.sin(Lambda / 10000**(i / 37))], dim=-1)
#                            for i in range(37)], dim=-1)
        Z = torch.stack([
            psi(Lambda).squeeze(dim=2)     # [B, D_pe]
            for psi in self.psi_list
        ], dim=2)                          # [B, D_pe, M]

        V_list = unbatch(V, batch, dim=0)   # [N_i, D_pe] * B
        Z_list = list(Z)                    # [D_pe, M] * B

        W_list = []                        # [N_i, N_i, M] * B
        for V, Z in zip(V_list, Z_list):   # [N_i, D_pe] and [D_pe, M]
            V = V.unsqueeze(dim=0)         # [1, N_i, D_pe]
            Z = Z.permute(1, 0)            # [M, D_pe]
            Z = Z.diag_embed()             # [M, D_pe, D_pe]
            V_T = V.mT                     # [1, D_pe, N_i]
            W = V.matmul(Z).matmul(V_T)    # [M, N_i, N_i]
            # W = V.matmul(V_T).repeat([Z.size(0), 1, 1])
            W = W.permute(1, 2, 0)         # [N_i, N_i, M]
            W_list.append(W)

        return self.phi(W_list, edge_index)   # [N_sum, D_pe]

    @property
    def out_dims(self) -> int:
        return self.phi.out_dims
